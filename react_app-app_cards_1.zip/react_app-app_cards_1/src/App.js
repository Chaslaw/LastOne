import React, {Component, Fragment} from 'react';
import './App.scss';


import { Header } from './components/Header/Header';
import { Cards } from './components/Cards/Cards';
import { Popup } from './components/Popup/Popup'

class App extends Component {

  state = {
    
       popup: true,
       data: [

            {
                name: "Peter",
                age: 35
            },
            {
                name: "Anna",
                age: 38
            },
            {
                name: "Mark",
                age: 30
            }
        ]
  }

    closePopup() {
        this.setState({
            popup: false,
          
        })


    }

    addData(data) {
        console.log(data)
    }

   render() {
        return (
            <Fragment>
                <Header search />
                <Cards data={this.state.data} />

                {this.state.popup && (
                    <Popup active={false} 
                           onPopupClose={() => this.closePopup()}
                           onFormSubmit={data => this.addData(data)} />
                )}
                
            
            </Fragment>
        )
    }

}

export default App;



