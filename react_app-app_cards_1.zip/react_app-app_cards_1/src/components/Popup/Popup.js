import React, { Component, Fragment } from 'react';
import './Popup.scss';

class Popup extends Component {

	state = {   
        name:'',
        lastName: '',
        age: null
     }


onSearchChange = (e) => {
	this.setState({
		name:e.target.value
	})
	
} 


	

    closePopup = () => {
       this.props.onPopupClose();
    }

	onFormSubmit = () => {
	   this.props.onFormSubmit(this.state);
       this.closePopup();
	}

	render(){
		return(
			<div className="form">

				<label>Name</label> 
				<input type="text" 
							onChange={(e)=>this.onSearchChange(e) }
							value={this.state.name}/>
                <button onClick={this.onFormSubmit}>Submit</button>
			</div>
		)
	}


}



export {Popup};