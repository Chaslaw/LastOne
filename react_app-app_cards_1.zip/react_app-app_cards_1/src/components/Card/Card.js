import React from 'react';


const Card = ({name, age}) => <li> {name} {age} </li>

export { Card };